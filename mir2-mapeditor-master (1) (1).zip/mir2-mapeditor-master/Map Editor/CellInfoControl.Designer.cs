﻿namespace Map_Editor
{
    partial class CellInfoControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.LabX = new System.Windows.Forms.Label();
            this.labY = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labBackImageIndex = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labMiddleImageIndex = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labFrontImageIndex = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labBVersion = new System.Windows.Forms.Label();
            this.labBLibName = new System.Windows.Forms.Label();
            this.labBLibIndex = new System.Windows.Forms.Label();
            this.labMLibIndex = new System.Windows.Forms.Label();
            this.labMLibName = new System.Windows.Forms.Label();
            this.labMVersion = new System.Windows.Forms.Label();
            this.labFLibIndex = new System.Windows.Forms.Label();
            this.labFLibName = new System.Windows.Forms.Label();
            this.labFVersion = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.LabBackLimit = new System.Windows.Forms.Label();
            this.labFrontLimit = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labFFrame = new System.Windows.Forms.Label();
            this.labFTick = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labFBlend = new System.Windows.Forms.Label();
            this.labMBlend = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.labMTick = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.labMFrame = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.labDoorOffSet = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.labDoorIndex = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.labEntityDoor = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.labLight = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.labfishing = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "X:";
            // 
            // LabX
            // 
            this.LabX.AutoSize = true;
            this.LabX.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabX.Location = new System.Drawing.Point(26, 10);
            this.LabX.Name = "LabX";
            this.LabX.Size = new System.Drawing.Size(15, 17);
            this.LabX.TabIndex = 1;
            this.LabX.Text = "0";
            // 
            // labY
            // 
            this.labY.AutoSize = true;
            this.labY.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labY.Location = new System.Drawing.Point(82, 10);
            this.labY.Name = "labY";
            this.labY.Size = new System.Drawing.Size(15, 17);
            this.labY.TabIndex = 3;
            this.labY.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(59, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Y:";
            // 
            // labBackImageIndex
            // 
            this.labBackImageIndex.AutoSize = true;
            this.labBackImageIndex.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labBackImageIndex.Location = new System.Drawing.Point(82, 29);
            this.labBackImageIndex.Name = "labBackImageIndex";
            this.labBackImageIndex.Size = new System.Drawing.Size(15, 17);
            this.labBackImageIndex.TabIndex = 5;
            this.labBackImageIndex.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "BackImage:";
            // 
            // labMiddleImageIndex
            // 
            this.labMiddleImageIndex.AutoSize = true;
            this.labMiddleImageIndex.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMiddleImageIndex.Location = new System.Drawing.Point(82, 48);
            this.labMiddleImageIndex.Name = "labMiddleImageIndex";
            this.labMiddleImageIndex.Size = new System.Drawing.Size(15, 17);
            this.labMiddleImageIndex.TabIndex = 7;
            this.labMiddleImageIndex.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "MiddleImage:";
            // 
            // labFrontImageIndex
            // 
            this.labFrontImageIndex.AutoSize = true;
            this.labFrontImageIndex.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFrontImageIndex.Location = new System.Drawing.Point(82, 67);
            this.labFrontImageIndex.Name = "labFrontImageIndex";
            this.labFrontImageIndex.Size = new System.Drawing.Size(15, 17);
            this.labFrontImageIndex.TabIndex = 9;
            this.labFrontImageIndex.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "FrontImage:";
            // 
            // labBVersion
            // 
            this.labBVersion.AutoSize = true;
            this.labBVersion.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labBVersion.Location = new System.Drawing.Point(120, 29);
            this.labBVersion.Name = "labBVersion";
            this.labBVersion.Size = new System.Drawing.Size(58, 17);
            this.labBVersion.TabIndex = 10;
            this.labBVersion.Text = "BVersion";
            // 
            // labBLibName
            // 
            this.labBLibName.AutoSize = true;
            this.labBLibName.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labBLibName.Location = new System.Drawing.Point(200, 29);
            this.labBLibName.Name = "labBLibName";
            this.labBLibName.Size = new System.Drawing.Size(49, 17);
            this.labBLibName.TabIndex = 11;
            this.labBLibName.Text = "objects";
            // 
            // labBLibIndex
            // 
            this.labBLibIndex.AutoSize = true;
            this.labBLibIndex.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labBLibIndex.Location = new System.Drawing.Point(288, 29);
            this.labBLibIndex.Name = "labBLibIndex";
            this.labBLibIndex.Size = new System.Drawing.Size(29, 17);
            this.labBLibIndex.TabIndex = 12;
            this.labBLibIndex.Text = "399";
            // 
            // labMLibIndex
            // 
            this.labMLibIndex.AutoSize = true;
            this.labMLibIndex.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMLibIndex.Location = new System.Drawing.Point(288, 46);
            this.labMLibIndex.Name = "labMLibIndex";
            this.labMLibIndex.Size = new System.Drawing.Size(29, 17);
            this.labMLibIndex.TabIndex = 15;
            this.labMLibIndex.Text = "399";
            // 
            // labMLibName
            // 
            this.labMLibName.AutoSize = true;
            this.labMLibName.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMLibName.Location = new System.Drawing.Point(200, 46);
            this.labMLibName.Name = "labMLibName";
            this.labMLibName.Size = new System.Drawing.Size(49, 17);
            this.labMLibName.TabIndex = 14;
            this.labMLibName.Text = "objects";
            // 
            // labMVersion
            // 
            this.labMVersion.AutoSize = true;
            this.labMVersion.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMVersion.Location = new System.Drawing.Point(120, 46);
            this.labMVersion.Name = "labMVersion";
            this.labMVersion.Size = new System.Drawing.Size(58, 17);
            this.labMVersion.TabIndex = 13;
            this.labMVersion.Text = "BVersion";
            // 
            // labFLibIndex
            // 
            this.labFLibIndex.AutoSize = true;
            this.labFLibIndex.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFLibIndex.Location = new System.Drawing.Point(288, 63);
            this.labFLibIndex.Name = "labFLibIndex";
            this.labFLibIndex.Size = new System.Drawing.Size(29, 17);
            this.labFLibIndex.TabIndex = 18;
            this.labFLibIndex.Text = "399";
            // 
            // labFLibName
            // 
            this.labFLibName.AutoSize = true;
            this.labFLibName.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFLibName.Location = new System.Drawing.Point(200, 63);
            this.labFLibName.Name = "labFLibName";
            this.labFLibName.Size = new System.Drawing.Size(49, 17);
            this.labFLibName.TabIndex = 17;
            this.labFLibName.Text = "objects";
            // 
            // labFVersion
            // 
            this.labFVersion.AutoSize = true;
            this.labFVersion.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFVersion.Location = new System.Drawing.Point(120, 63);
            this.labFVersion.Name = "labFVersion";
            this.labFVersion.Size = new System.Drawing.Size(58, 17);
            this.labFVersion.TabIndex = 16;
            this.labFVersion.Text = "BVersion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(124, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 17);
            this.label2.TabIndex = 19;
            this.label2.Text = "Version";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(198, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 17);
            this.label3.TabIndex = 20;
            this.label3.Text = "LibName";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(262, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 17);
            this.label5.TabIndex = 21;
            this.label5.Text = "LibIndex";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 17);
            this.label7.TabIndex = 22;
            this.label7.Text = "Limit:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(64, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 17);
            this.label9.TabIndex = 23;
            this.label9.Text = "Back";
            // 
            // LabBackLimit
            // 
            this.LabBackLimit.AutoSize = true;
            this.LabBackLimit.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabBackLimit.Location = new System.Drawing.Point(100, 84);
            this.LabBackLimit.Name = "LabBackLimit";
            this.LabBackLimit.Size = new System.Drawing.Size(40, 17);
            this.LabBackLimit.TabIndex = 24;
            this.LabBackLimit.Text = "Back=";
            // 
            // labFrontLimit
            // 
            this.labFrontLimit.AutoSize = true;
            this.labFrontLimit.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFrontLimit.Location = new System.Drawing.Point(253, 84);
            this.labFrontLimit.Name = "labFrontLimit";
            this.labFrontLimit.Size = new System.Drawing.Size(40, 17);
            this.labFrontLimit.TabIndex = 26;
            this.labFrontLimit.Text = "Back=";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(213, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 17);
            this.label12.TabIndex = 25;
            this.label12.Text = "Front";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 17);
            this.label11.TabIndex = 27;
            this.label11.Text = "Animation:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(65, 101);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 17);
            this.label13.TabIndex = 28;
            this.label13.Text = "F_Frame";
            // 
            // labFFrame
            // 
            this.labFFrame.AutoSize = true;
            this.labFFrame.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFFrame.Location = new System.Drawing.Point(120, 101);
            this.labFFrame.Name = "labFFrame";
            this.labFFrame.Size = new System.Drawing.Size(20, 17);
            this.labFFrame.TabIndex = 29;
            this.labFFrame.Text = "10";
            // 
            // labFTick
            // 
            this.labFTick.AutoSize = true;
            this.labFTick.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFTick.Location = new System.Drawing.Point(187, 101);
            this.labFTick.Name = "labFTick";
            this.labFTick.Size = new System.Drawing.Size(13, 17);
            this.labFTick.TabIndex = 31;
            this.labFTick.Text = "1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(141, 101);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 17);
            this.label15.TabIndex = 30;
            this.label15.Text = "F_Tick";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(213, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 17);
            this.label14.TabIndex = 32;
            this.label14.Text = "F_Blend";
            // 
            // labFBlend
            // 
            this.labFBlend.AutoSize = true;
            this.labFBlend.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFBlend.Location = new System.Drawing.Point(264, 101);
            this.labFBlend.Name = "labFBlend";
            this.labFBlend.Size = new System.Drawing.Size(32, 17);
            this.labFBlend.TabIndex = 33;
            this.labFBlend.Text = "true";
            // 
            // labMBlend
            // 
            this.labMBlend.AutoSize = true;
            this.labMBlend.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMBlend.Location = new System.Drawing.Point(264, 118);
            this.labMBlend.Name = "labMBlend";
            this.labMBlend.Size = new System.Drawing.Size(32, 17);
            this.labMBlend.TabIndex = 40;
            this.labMBlend.Text = "true";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(213, 118);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 17);
            this.label17.TabIndex = 39;
            this.label17.Text = "M_Blend";
            // 
            // labMTick
            // 
            this.labMTick.AutoSize = true;
            this.labMTick.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMTick.Location = new System.Drawing.Point(187, 118);
            this.labMTick.Name = "labMTick";
            this.labMTick.Size = new System.Drawing.Size(13, 17);
            this.labMTick.TabIndex = 38;
            this.labMTick.Text = "1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(141, 118);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(50, 17);
            this.label19.TabIndex = 37;
            this.label19.Text = "M_Tick";
            // 
            // labMFrame
            // 
            this.labMFrame.AutoSize = true;
            this.labMFrame.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMFrame.Location = new System.Drawing.Point(120, 118);
            this.labMFrame.Name = "labMFrame";
            this.labMFrame.Size = new System.Drawing.Size(20, 17);
            this.labMFrame.TabIndex = 36;
            this.labMFrame.Text = "10";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(65, 118);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 17);
            this.label21.TabIndex = 35;
            this.label21.Text = "M_Frame";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(3, 118);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(66, 17);
            this.label22.TabIndex = 34;
            this.label22.Text = "Animation:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 135);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 17);
            this.label16.TabIndex = 41;
            this.label16.Text = "Door:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(65, 135);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 17);
            this.label18.TabIndex = 42;
            this.label18.Text = "OffSet";
            // 
            // labDoorOffSet
            // 
            this.labDoorOffSet.AutoSize = true;
            this.labDoorOffSet.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labDoorOffSet.Location = new System.Drawing.Point(121, 135);
            this.labDoorOffSet.Name = "labDoorOffSet";
            this.labDoorOffSet.Size = new System.Drawing.Size(15, 17);
            this.labDoorOffSet.TabIndex = 43;
            this.labDoorOffSet.Text = "5";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(141, 135);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(40, 17);
            this.label20.TabIndex = 44;
            this.label20.Text = "Index";
            // 
            // labDoorIndex
            // 
            this.labDoorIndex.AutoSize = true;
            this.labDoorIndex.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labDoorIndex.Location = new System.Drawing.Point(184, 135);
            this.labDoorIndex.Name = "labDoorIndex";
            this.labDoorIndex.Size = new System.Drawing.Size(15, 17);
            this.labDoorIndex.TabIndex = 45;
            this.labDoorIndex.Text = "5";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(213, 135);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 17);
            this.label23.TabIndex = 46;
            this.label23.Text = "Entity";
            // 
            // labEntityDoor
            // 
            this.labEntityDoor.AutoSize = true;
            this.labEntityDoor.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labEntityDoor.Location = new System.Drawing.Point(263, 135);
            this.labEntityDoor.Name = "labEntityDoor";
            this.labEntityDoor.Size = new System.Drawing.Size(32, 17);
            this.labEntityDoor.TabIndex = 47;
            this.labEntityDoor.Text = "true";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(3, 152);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 17);
            this.label24.TabIndex = 48;
            this.label24.Text = "Light:";
            // 
            // labLight
            // 
            this.labLight.AutoSize = true;
            this.labLight.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labLight.Location = new System.Drawing.Point(48, 152);
            this.labLight.Name = "labLight";
            this.labLight.Size = new System.Drawing.Size(15, 17);
            this.labLight.TabIndex = 49;
            this.labLight.Text = "5";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(124, 152);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 17);
            this.label25.TabIndex = 50;
            this.label25.Text = "Fishing:";
            // 
            // labfishing
            // 
            this.labfishing.AutoSize = true;
            this.labfishing.Font = new System.Drawing.Font("Comic Sans MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labfishing.Location = new System.Drawing.Point(181, 152);
            this.labfishing.Name = "labfishing";
            this.labfishing.Size = new System.Drawing.Size(32, 17);
            this.labfishing.TabIndex = 51;
            this.labfishing.Text = "true";
            // 
            // CellInfoControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.labfishing);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.labLight);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.labEntityDoor);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.labDoorIndex);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.labDoorOffSet);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.labMBlend);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.labMTick);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.labMFrame);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.labFBlend);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.labFTick);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.labFFrame);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.labFrontLimit);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.LabBackLimit);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labFLibIndex);
            this.Controls.Add(this.labFLibName);
            this.Controls.Add(this.labFVersion);
            this.Controls.Add(this.labMLibIndex);
            this.Controls.Add(this.labMLibName);
            this.Controls.Add(this.labMVersion);
            this.Controls.Add(this.labBLibIndex);
            this.Controls.Add(this.labBLibName);
            this.Controls.Add(this.labBVersion);
            this.Controls.Add(this.labFrontImageIndex);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labMiddleImageIndex);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.labBackImageIndex);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labY);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.LabX);
            this.Controls.Add(this.label1);
            this.Name = "CellInfoControl";
            this.Size = new System.Drawing.Size(316, 175);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LabX;
        private System.Windows.Forms.Label labY;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labBackImageIndex;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labMiddleImageIndex;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labFrontImageIndex;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labBVersion;
        private System.Windows.Forms.Label labBLibName;
        private System.Windows.Forms.Label labBLibIndex;
        private System.Windows.Forms.Label labMLibIndex;
        private System.Windows.Forms.Label labMLibName;
        private System.Windows.Forms.Label labMVersion;
        private System.Windows.Forms.Label labFLibIndex;
        private System.Windows.Forms.Label labFLibName;
        private System.Windows.Forms.Label labFVersion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label LabBackLimit;
        private System.Windows.Forms.Label labFrontLimit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labFFrame;
        private System.Windows.Forms.Label labFTick;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labFBlend;
        private System.Windows.Forms.Label labMBlend;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label labMTick;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label labMFrame;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label labDoorOffSet;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label labDoorIndex;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label labEntityDoor;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label labLight;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label labfishing;
    }
}
